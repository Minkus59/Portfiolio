<?php 
require_once($_SERVER['DOCUMENT_ROOT']."/impinfbdd/config.inc.php");
require_once($_SERVER['DOCUMENT_ROOT']."/controller/page.inc.php");  

require_once($_SERVER['DOCUMENT_ROOT']."/controller/head.inc.php");
require_once($_SERVER['DOCUMENT_ROOT']."/controller/header.inc.php"); 
require_once($_SERVER['DOCUMENT_ROOT']."/views/nav.inc.php"); 

require_once($_SERVER['DOCUMENT_ROOT']."/controller/article.inc.php"); 

require_once($_SERVER['DOCUMENT_ROOT']."/views/contact/contact.inc.php");
require_once($_SERVER['DOCUMENT_ROOT']."/controller/footer.inc.php"); 
?>
