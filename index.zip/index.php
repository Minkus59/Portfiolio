<?php 
require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/fonction_perso.inc.php");  
require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/redirect.inc.php");
require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/requete.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/head.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/header.inc.php"); 

require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/nav.inc.php"); 

require_once($_SERVER['DOCUMENT_ROOT']."/lib/article/presentation.inc.php"); 

require_once($_SERVER['DOCUMENT_ROOT']."/lib/article/competence.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/article/cv.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/article/portfolio.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/article/contact.inc.php");

require_once($_SERVER['DOCUMENT_ROOT']."/lib/script/footer.inc.php"); 
?>
